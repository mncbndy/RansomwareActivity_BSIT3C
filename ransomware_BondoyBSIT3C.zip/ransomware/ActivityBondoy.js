const encryptor = require("file-encryptor");
const readlineSync = require("readline-sync");
const fs = require("fs");

const encryptionKey = "idontknowthepassword";
const topsecret = "./topsecret";

async function processFiles(encrypt) {
  try {
    const files = fs.readdirSync(topsecret);
    const action = encrypt ? "encrypted" : "decrypted";

    for (const file of files) {
      if (
        (encrypt && !file.endsWith(".encrypt")) ||
        (!encrypt && file.endsWith(".encrypt"))
      ) {
        const inputFilePath = `${topsecret}/${file}`;
        const outputFilePath = encrypt
          ? `${inputFilePath}.encrypt`
          : inputFilePath.replace(".encrypt", "");

        await new Promise((resolve, reject) => {
          const method = encrypt
            ? encryptor.encryptFile
            : encryptor.decryptFile;
          method(inputFilePath, outputFilePath, encryptionKey, (err) => {
            if (err) reject(err);
            else {
              if (encrypt) {
                console.log(`All files encrypted successfully.`);
              } else {
                console.log(`All files decrypted successfully.`);
              }

              fs.unlink(inputFilePath, (err) => {
                if (err) reject(err);
                else resolve();
              });
            }
          });
        });
      }
    }
  } catch (err) {
    console.error("Error:", err);
  }
}

(async () => {
  const encrypting = true;
  await processFiles(encrypting);

  if (encrypting) {
    const decryptionKey = readlineSync.question(
      "Please enter the decryption key here:"
    );
    if (decryptionKey.toLowerCase() === "exit") {
      console.log("Exiting decryption process.");
      return;
    }
    await processFiles(false);
  }
})();
